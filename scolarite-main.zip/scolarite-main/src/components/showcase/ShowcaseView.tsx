import React, { useState } from 'react';
import {
  School,
  LogIn,
  UserPlus,
  ShieldCheck,
  Award,
  Users,
  GraduationCap,
  Calendar,
  Clock,
  Phone,
  Mail,
  MapPin,
  CheckCircle2,
  ArrowRight,
  BookOpen,
  Bus,
  Utensils,
  Laptop,
  HeartHandshake,
  FileCheck,
  ChevronRight,
  Sparkles,
  ExternalLink,
  Moon,
  Sun,
  Lock,
} from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { LoginModal } from './LoginModal';
import { PreRegisterModal } from './PreRegisterModal';
import { UserRole } from '../../types';

export const ShowcaseView: React.FC = () => {
  const {
    currentEstablishment,
    isAuthenticated,
    currentUser,
    setViewMode,
    darkMode,
    toggleDarkMode,
    classes,
    students,
    teachers,
    login,
  } = useApp();

  const [showLoginModal, setShowLoginModal] = useState(false);
  const [showPreRegisterModal, setShowPreRegisterModal] = useState(false);
  const [defaultLoginRole, setDefaultLoginRole] = useState<UserRole | undefined>(undefined);

  // Quick contact form state
  const [contactName, setContactName] = useState('');
  const [contactPhone, setContactPhone] = useState('');
  const [contactMessage, setContactMessage] = useState('');
  const [contactSent, setContactSent] = useState(false);

  const handleOpenLoginWithRole = (role: UserRole) => {
    setDefaultLoginRole(role);
    setShowLoginModal(true);
  };

  const handleContactSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!contactName || !contactPhone || !contactMessage) return;
    setContactSent(true);
    setTimeout(() => {
      setContactName('');
      setContactPhone('');
      setContactMessage('');
    }, 2000);
  };

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-950 text-slate-800 dark:text-slate-100 font-sans selection:bg-blue-500 selection:text-white transition-colors">
      {/* 1. Official National Banner */}
      <div className="bg-[#0f1f35] text-white text-[11px] py-1.5 px-4 border-b border-white/10">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-1 text-center sm:text-left">
          <div className="flex items-center gap-2 text-slate-300">
            <span className="font-bold text-amber-400">RÉPUBLIQUE DE CÔTE D’IVOIRE</span>
            <span className="hidden sm:inline">·</span>
            <span className="hidden sm:inline">Ministère de l’Éducation Nationale et de l’Alphabétisation</span>
            <span>·</span>
            <span className="text-white font-semibold">DRENA Duékoué</span>
          </div>
          <div className="flex items-center gap-4 text-slate-300 text-[10px]">
            <span>Année Scolaire {currentEstablishment.currentYear}</span>
            <span>·</span>
            <span>Tél: {currentEstablishment.phone}</span>
          </div>
        </div>
      </div>

      {/* 2. Main Navigation Bar */}
      <header className="sticky top-0 z-40 bg-white/95 dark:bg-slate-900/95 backdrop-blur-md border-b border-slate-200 dark:border-slate-800 transition-colors">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-20 flex items-center justify-between gap-4">
          {/* Logo & School Identity */}
          <div className="flex items-center gap-3.5">
            <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-[#142B49] to-blue-700 text-white flex items-center justify-center shadow-lg shadow-blue-900/20 ring-2 ring-blue-500/20 shrink-0">
              <School className="w-6 h-6 text-amber-300" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-lg sm:text-xl font-black text-slate-900 dark:text-white tracking-tight">
                  {currentEstablishment.name}
                </h1>
                <span className="hidden md:inline-block text-[10px] font-mono font-bold px-1.5 py-0.5 rounded bg-blue-100 dark:bg-blue-950/60 text-blue-700 dark:text-blue-300 border border-blue-200 dark:border-blue-800">
                  {currentEstablishment.code}
                </span>
              </div>
              <p className="text-[11px] text-slate-500 dark:text-slate-400 font-medium">
                {currentEstablishment.motto} · {currentEstablishment.city}
              </p>
            </div>
          </div>

          {/* Center Links (Desktop) */}
          <nav className="hidden lg:flex items-center gap-7 text-xs font-bold text-slate-600 dark:text-slate-300">
            <a href="#presentation" className="hover:text-blue-600 dark:hover:text-blue-400 transition-colors">
              Présentation
            </a>
            <a href="#portails" className="hover:text-blue-600 dark:hover:text-blue-400 transition-colors flex items-center gap-1">
              <span>Portails Numériques</span>
              <span className="w-1.5 h-1.5 rounded-full bg-blue-600"></span>
            </a>
            <a href="#formations" className="hover:text-blue-600 dark:hover:text-blue-400 transition-colors">
              Formations
            </a>
            <a href="#viescolaire" className="hover:text-blue-600 dark:hover:text-blue-400 transition-colors">
              Vie Scolaire
            </a>
            <a href="#actualites" className="hover:text-blue-600 dark:hover:text-blue-400 transition-colors">
              Actualités
            </a>
            <a href="#contact" className="hover:text-blue-600 dark:hover:text-blue-400 transition-colors">
              Contact
            </a>
          </nav>

          {/* Action CTAs */}
          <div className="flex items-center gap-2.5">
            {/* Dark mode button */}
            <button
              onClick={toggleDarkMode}
              className="p-2 rounded-xl text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
              aria-label="Mode sombre"
            >
              {darkMode ? <Sun className="w-4 h-4 text-amber-400" /> : <Moon className="w-4 h-4" />}
            </button>

            {/* Pre-inscription button */}
            <button
              onClick={() => setShowPreRegisterModal(true)}
              className="hidden sm:flex items-center gap-1.5 px-3.5 py-2 rounded-xl border border-slate-300 dark:border-slate-700 hover:bg-slate-100 dark:hover:bg-slate-800 text-xs font-bold text-slate-700 dark:text-slate-200 transition-all cursor-pointer"
            >
              <UserPlus className="w-3.5 h-3.5 text-blue-600 dark:text-blue-400" />
              <span>Pré-inscription</span>
            </button>

            {/* Login / Access App button */}
            {isAuthenticated ? (
              <button
                onClick={() => setViewMode('app')}
                className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-700 active:scale-[0.98] text-white text-xs font-extrabold shadow-md shadow-blue-500/20 transition-all cursor-pointer"
              >
                <span>Accéder à l’Espace Gestion</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            ) : (
              <button
                onClick={() => {
                  setDefaultLoginRole(undefined);
                  setShowLoginModal(true);
                }}
                className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-[#142B49] hover:bg-blue-900 active:scale-[0.98] text-white text-xs font-extrabold shadow-md transition-all cursor-pointer"
              >
                <LogIn className="w-4 h-4 text-amber-400" />
                <span>Se Connecter</span>
              </button>
            )}
          </div>
        </div>
      </header>

      {/* 3. Hero Section */}
      <section className="relative overflow-hidden bg-gradient-to-b from-[#142B49] via-[#1a385f] to-[#142B49] text-white py-16 sm:py-24">
        {/* Decorative Grid Background */}
        <div
          className="absolute inset-0 opacity-10 bg-[radial-gradient(#ffffff_1px,transparent_1px)] [background-size:24px_24px] pointer-events-none"
          aria-hidden="true"
        />

        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
            {/* Left Column: Heading & CTAs */}
            <div className="lg:col-span-7 space-y-6 text-center lg:text-left">
              <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-white/10 border border-white/20 text-xs font-semibold text-blue-200">
                <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
                <span>Portail Numérique Officiel · Année Scolaire {currentEstablishment.currentYear}</span>
              </div>

              <h2 className="text-3xl sm:text-5xl lg:text-5xl font-black text-white tracking-tight leading-tight">
                Former les leaders de demain au cœur du{' '}
                <span className="text-amber-400 underline decoration-amber-400/40 decoration-4">
                  Guémon
                </span>
              </h2>

              <p className="text-sm sm:text-base text-slate-200 max-w-2xl mx-auto lg:mx-0 leading-relaxed font-normal">
                Bienvenue sur la plateforme officielle du <strong>{currentEstablishment.name}</strong>.
                Un établissement d’excellence engagé dans la réussite éducative, la rigueur républicaine
                et le suivi pédagogique en direct pour les élèves et les familles de Bagohouo.
              </p>

              {/* Action Buttons */}
              <div className="flex flex-wrap items-center justify-center lg:justify-start gap-3 pt-2">
                <a
                  href="#portails"
                  className="px-6 py-3.5 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-extrabold text-sm shadow-xl shadow-blue-500/30 transition-all flex items-center gap-2 group cursor-pointer"
                >
                  <Lock className="w-4 h-4 text-amber-300" />
                  <span>Accéder aux Portails Scolaires</span>
                  <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
                </a>

                <button
                  onClick={() => setShowPreRegisterModal(true)}
                  className="px-6 py-3.5 rounded-xl bg-white/10 hover:bg-white/20 text-white font-bold text-sm border border-white/20 transition-all flex items-center gap-2 cursor-pointer"
                >
                  <UserPlus className="w-4 h-4 text-blue-300" />
                  <span>Demande de Pré-inscription</span>
                </button>
              </div>

              {/* Reassurance bullet list */}
              <div className="pt-4 flex flex-wrap items-center justify-center lg:justify-start gap-5 text-xs text-slate-300">
                <div className="flex items-center gap-1.5">
                  <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                  <span>Bulletins Officiels Numérisés</span>
                </div>
                <div className="flex items-center gap-1.5">
                  <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                  <span>Suivi d’assiduité en temps réel</span>
                </div>
                <div className="flex items-center gap-1.5">
                  <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                  <span>Paiements & Reçus sécurisés</span>
                </div>
              </div>
            </div>

            {/* Right Column: Visual Showcase Card */}
            <div className="lg:col-span-5">
              <div className="relative rounded-3xl bg-white/10 backdrop-blur-md p-6 sm:p-8 border border-white/20 shadow-2xl">
                <div className="flex items-center justify-between pb-4 border-b border-white/15">
                  <div className="flex items-center gap-3">
                    <img
                      src={currentEstablishment.logoUrl}
                      alt="Logo CMB"
                      className="w-12 h-12 rounded-xl object-cover ring-2 ring-white/30"
                    />
                    <div>
                      <p className="text-xs uppercase font-extrabold text-amber-300">Collège Moderne</p>
                      <p className="text-sm font-bold text-white">Bagohouo, Duékoué</p>
                    </div>
                  </div>
                  <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-400/30">
                    Établissement Agréé
                  </span>
                </div>

                <div className="mt-5 space-y-4">
                  <div className="p-3.5 rounded-2xl bg-white/5 border border-white/10 flex items-center gap-3">
                    <div className="w-10 h-10 rounded-xl bg-blue-500/20 text-blue-300 flex items-center justify-center font-bold">
                      <GraduationCap className="w-5 h-5" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-xs font-bold text-white">Directeur de l'Établissement</p>
                      <p className="text-[11px] text-slate-300">{currentEstablishment.directorName}</p>
                    </div>
                  </div>

                  <div className="p-3.5 rounded-2xl bg-white/5 border border-white/10 flex items-center gap-3">
                    <div className="w-10 h-10 rounded-xl bg-amber-500/20 text-amber-300 flex items-center justify-center font-bold">
                      <Award className="w-5 h-5" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-xs font-bold text-white">Taux de Réussite BEPC 2024</p>
                      <p className="text-[11px] text-slate-300">96.4% d’admis parmi les candidats présentés</p>
                    </div>
                  </div>

                  <div className="p-3.5 rounded-2xl bg-white/5 border border-white/10 flex items-center gap-3">
                    <div className="w-10 h-10 rounded-xl bg-emerald-500/20 text-emerald-300 flex items-center justify-center font-bold">
                      <Clock className="w-5 h-5" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-xs font-bold text-white">Horaires des Cours</p>
                      <p className="text-[11px] text-slate-300">Lundi au Vendredi : 07h30 - 17h30 (Pause 12h-14h)</p>
                    </div>
                  </div>
                </div>

                <div className="mt-6 pt-4 border-t border-white/15 flex items-center justify-between text-xs">
                  <span className="text-slate-300">Envie de rejoindre l'établissement ?</span>
                  <button
                    onClick={() => setShowPreRegisterModal(true)}
                    className="font-bold text-amber-300 hover:text-white transition-colors flex items-center gap-1"
                  >
                    <span>Postuler</span>
                    <ChevronRight className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* 4. Key Stats Counter */}
      <section className="bg-white dark:bg-slate-900 border-b border-slate-200 dark:border-slate-800 py-8">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-6 text-center">
            <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/50">
              <p className="text-3xl sm:text-4xl font-black text-blue-600 dark:text-blue-400">850+</p>
              <p className="text-xs font-bold text-slate-600 dark:text-slate-300 mt-1">Élèves Inscrits</p>
              <p className="text-[10px] text-slate-400 mt-0.5">Premier cycle secondaire complet</p>
            </div>
            <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/50">
              <p className="text-3xl sm:text-4xl font-black text-emerald-600 dark:text-emerald-400">96.4%</p>
              <p className="text-xs font-bold text-slate-600 dark:text-slate-300 mt-1">Réussite au BEPC</p>
              <p className="text-[10px] text-slate-400 mt-0.5">Parmi les meilleurs taux de la DRENA</p>
            </div>
            <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/50">
              <p className="text-3xl sm:text-4xl font-black text-indigo-600 dark:text-indigo-400">38</p>
              <p className="text-xs font-bold text-slate-600 dark:text-slate-300 mt-1">Enseignants & Éducateurs</p>
              <p className="text-[10px] text-slate-400 mt-0.5">Professeurs certifiés de l'ENS</p>
            </div>
            <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/50">
              <p className="text-3xl sm:text-4xl font-black text-amber-600 dark:text-amber-400">100%</p>
              <p className="text-xs font-bold text-slate-600 dark:text-slate-300 mt-1">Suivi Numérique</p>
              <p className="text-[10px] text-slate-400 mt-0.5">Notes, assiduité, cartes et reçus</p>
            </div>
          </div>
        </div>
      </section>

      {/* 5. PORTAILS D'ACCÈS NUMÉRIQUE (Main Requirement) */}
      <section id="portails" className="py-16 sm:py-20 bg-slate-100/70 dark:bg-slate-950/60">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center max-w-3xl mx-auto space-y-3 mb-12">
            <div className="inline-flex items-center gap-1.5 text-xs font-bold text-blue-600 dark:text-blue-400 uppercase tracking-wider">
              <Lock className="w-3.5 h-3.5" />
              <span>Espaces Utilisateurs Sécurisés</span>
            </div>
            <h3 className="text-2xl sm:text-4xl font-black text-slate-900 dark:text-white tracking-tight">
              Choisissez votre espace pour vous connecter
            </h3>
            <p className="text-xs sm:text-sm text-slate-600 dark:text-slate-400">
              Chaque membre de la communauté éducative accède à son espace personnalisé avec ses identifiants
              ou en un clic via nos comptes de démonstration pré-configurés.
            </p>
          </div>

          {/* Grid of Portals */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {/* 1. Espace Direction & Administration */}
            <div className="bg-white dark:bg-slate-900 rounded-3xl p-6 border border-slate-200 dark:border-slate-800 shadow-sm hover:shadow-xl hover:border-blue-500 transition-all flex flex-col justify-between group">
              <div>
                <div className="w-12 h-12 rounded-2xl bg-blue-100 dark:bg-blue-900/40 text-blue-600 dark:text-blue-400 flex items-center justify-center mb-4 group-hover:scale-110 transition-transform">
                  <ShieldCheck className="w-6 h-6" />
                </div>
                <h4 className="text-base font-extrabold text-slate-900 dark:text-white">
                  Direction & Administration
                </h4>
                <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
                  M. Kouadio Laurent (Directeur) et Mme Brou (Directrice des Études)
                </p>
                <ul className="mt-4 space-y-2 text-xs text-slate-600 dark:text-slate-300">
                  <li className="flex items-center gap-2">
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-500 shrink-0" />
                    <span>Tableau de bord stratégique & effectifs</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-500 shrink-0" />
                    <span>Délibérations de conseils de classe</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-500 shrink-0" />
                    <span>Gestion des enseignants et emplois du temps</span>
                  </li>
                </ul>
              </div>

              <button
                onClick={() => handleOpenLoginWithRole('directeur')}
                className="mt-6 w-full py-2.5 px-4 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs shadow-sm transition-all flex items-center justify-center gap-2 cursor-pointer"
              >
                <span>Connexion Espace Direction</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>

            {/* 2. Espace Enseignants & Pédagogie */}
            <div className="bg-white dark:bg-slate-900 rounded-3xl p-6 border border-slate-200 dark:border-slate-800 shadow-sm hover:shadow-xl hover:border-blue-500 transition-all flex flex-col justify-between group">
              <div>
                <div className="w-12 h-12 rounded-2xl bg-indigo-100 dark:bg-indigo-900/40 text-indigo-600 dark:text-indigo-400 flex items-center justify-center mb-4 group-hover:scale-110 transition-transform">
                  <GraduationCap className="w-6 h-6" />
                </div>
                <h4 className="text-base font-extrabold text-slate-900 dark:text-white">
                  Corps Enseignant & Pédagogie
                </h4>
                <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
                  M. Koné Ibrahim (Mathématiques) & Équipe pédagogique
                </p>
                <ul className="mt-4 space-y-2 text-xs text-slate-600 dark:text-slate-300">
                  <li className="flex items-center gap-2">
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-500 shrink-0" />
                    <span>Saisie des notes (Devoirs & Compositions)</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-500 shrink-0" />
                    <span>Appel numérique des présences du jour</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-500 shrink-0" />
                    <span>Cahier de texte et appréciations d'élèves</span>
                  </li>
                </ul>
              </div>

              <button
                onClick={() => handleOpenLoginWithRole('enseignant')}
                className="mt-6 w-full py-2.5 px-4 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs shadow-sm transition-all flex items-center justify-center gap-2 cursor-pointer"
              >
                <span>Connexion Espace Enseignant</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>

            {/* 3. Espace Parents d'Élèves */}
            <div className="bg-white dark:bg-slate-900 rounded-3xl p-6 border border-slate-200 dark:border-slate-800 shadow-sm hover:shadow-xl hover:border-blue-500 transition-all flex flex-col justify-between group">
              <div>
                <div className="w-12 h-12 rounded-2xl bg-teal-100 dark:bg-teal-900/40 text-teal-600 dark:text-teal-400 flex items-center justify-center mb-4 group-hover:scale-110 transition-transform">
                  <Users className="w-6 h-6" />
                </div>
                <h4 className="text-base font-extrabold text-slate-900 dark:text-white">
                  Portail Familles & Parents
                </h4>
                <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
                  M. Koffi Jérôme (Parent d'élève) et Association COGES
                </p>
                <ul className="mt-4 space-y-2 text-xs text-slate-600 dark:text-slate-300">
                  <li className="flex items-center gap-2">
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-500 shrink-0" />
                    <span>Consultation instantanée des notes et moyennes</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-500 shrink-0" />
                    <span>Téléchargement des bulletins trimestriels officiels</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-500 shrink-0" />
                    <span>Suivi des paiements et solde de scolarité</span>
                  </li>
                </ul>
              </div>

              <button
                onClick={() => handleOpenLoginWithRole('parent')}
                className="mt-6 w-full py-2.5 px-4 rounded-xl bg-teal-600 hover:bg-teal-700 text-white font-bold text-xs shadow-sm transition-all flex items-center justify-center gap-2 cursor-pointer"
              >
                <span>Connexion Espace Parents</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>

            {/* 4. Espace Élèves */}
            <div className="bg-white dark:bg-slate-900 rounded-3xl p-6 border border-slate-200 dark:border-slate-800 shadow-sm hover:shadow-xl hover:border-blue-500 transition-all flex flex-col justify-between group">
              <div>
                <div className="w-12 h-12 rounded-2xl bg-sky-100 dark:bg-sky-900/40 text-sky-600 dark:text-sky-400 flex items-center justify-center mb-4 group-hover:scale-110 transition-transform">
                  <BookOpen className="w-6 h-6" />
                </div>
                <h4 className="text-base font-extrabold text-slate-900 dark:text-white">
                  Espace Apprenants & Élèves
                </h4>
                <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
                  Koffi Aya Marie (Tle D) & Élèves du collège
                </p>
                <ul className="mt-4 space-y-2 text-xs text-slate-600 dark:text-slate-300">
                  <li className="flex items-center gap-2">
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-500 shrink-0" />
                    <span>Emploi du temps de la semaine et salles</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-500 shrink-0" />
                    <span>Devoirs à la maison et calendrier des examens</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-500 shrink-0" />
                    <span>Carte scolaire numérique avec QR Code</span>
                  </li>
                </ul>
              </div>

              <button
                onClick={() => handleOpenLoginWithRole('eleve')}
                className="mt-6 w-full py-2.5 px-4 rounded-xl bg-sky-600 hover:bg-sky-700 text-white font-bold text-xs shadow-sm transition-all flex items-center justify-center gap-2 cursor-pointer"
              >
                <span>Connexion Espace Élève</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>

            {/* 5. Espace Comptabilité & Trésorerie */}
            <div className="bg-white dark:bg-slate-900 rounded-3xl p-6 border border-slate-200 dark:border-slate-800 shadow-sm hover:shadow-xl hover:border-blue-500 transition-all flex flex-col justify-between group">
              <div>
                <div className="w-12 h-12 rounded-2xl bg-emerald-100 dark:bg-emerald-900/40 text-emerald-600 dark:text-emerald-400 flex items-center justify-center mb-4 group-hover:scale-110 transition-transform">
                  <FileCheck className="w-6 h-6" />
                </div>
                <h4 className="text-base font-extrabold text-slate-900 dark:text-white">
                  Comptabilité & Intendance
                </h4>
                <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
                  M. Silué Yacouba (Chef Comptable)
                </p>
                <ul className="mt-4 space-y-2 text-xs text-slate-600 dark:text-slate-300">
                  <li className="flex items-center gap-2">
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-500 shrink-0" />
                    <span>Encaissement scolarité (Espèces, Wave, MoMo)</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-500 shrink-0" />
                    <span>Émission instantanée des reçus officiels REC</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-500 shrink-0" />
                    <span>Journal de caisse, dépenses et suivi des impayés</span>
                  </li>
                </ul>
              </div>

              <button
                onClick={() => handleOpenLoginWithRole('comptable')}
                className="mt-6 w-full py-2.5 px-4 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs shadow-sm transition-all flex items-center justify-center gap-2 cursor-pointer"
              >
                <span>Connexion Comptabilité</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>

            {/* 6. Vie Scolaire & Surveillance Générale */}
            <div className="bg-white dark:bg-slate-900 rounded-3xl p-6 border border-slate-200 dark:border-slate-800 shadow-sm hover:shadow-xl hover:border-blue-500 transition-all flex flex-col justify-between group">
              <div>
                <div className="w-12 h-12 rounded-2xl bg-amber-100 dark:bg-amber-900/40 text-amber-600 dark:text-amber-400 flex items-center justify-center mb-4 group-hover:scale-110 transition-transform">
                  <Clock className="w-6 h-6" />
                </div>
                <h4 className="text-base font-extrabold text-slate-900 dark:text-white">
                  Vie Scolaire & Discipline
                </h4>
                <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
                  M. Dago Marcellin (Surveillant Général)
                </p>
                <ul className="mt-4 space-y-2 text-xs text-slate-600 dark:text-slate-300">
                  <li className="flex items-center gap-2">
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-500 shrink-0" />
                    <span>Contrôle des retards et justificatifs d’absence</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-500 shrink-0" />
                    <span>Délivrance des billets d’entrée en classe</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-500 shrink-0" />
                    <span>Notification immédiate aux parents d’élèves</span>
                  </li>
                </ul>
              </div>

              <button
                onClick={() => handleOpenLoginWithRole('surveillant')}
                className="mt-6 w-full py-2.5 px-4 rounded-xl bg-amber-600 hover:bg-amber-700 text-white font-bold text-xs shadow-sm transition-all flex items-center justify-center gap-2 cursor-pointer"
              >
                <span>Connexion Vie Scolaire</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* 6. Section Présentation & Mot du Directeur */}
      <section id="presentation" className="py-16 sm:py-20 bg-white dark:bg-slate-900 border-b border-slate-200 dark:border-slate-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
            {/* Photo du Directeur */}
            <div className="lg:col-span-5 text-center">
              <div className="relative inline-block">
                <img
                  src="https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=500&h=600&q=80"
                  alt="M. Kouadio Laurent, Directeur du Collège Moderne Bagohouo"
                  className="w-72 h-88 sm:w-80 sm:h-96 object-cover rounded-3xl shadow-2xl ring-8 ring-blue-500/10 mx-auto"
                />
                <div className="absolute -bottom-4 left-1/2 -translate-x-1/2 bg-[#142B49] text-white py-2 px-5 rounded-2xl shadow-xl text-center whitespace-nowrap border border-blue-400/30">
                  <p className="text-xs font-black">M. Kouadio Laurent</p>
                  <p className="text-[10px] text-amber-300">Directeur du Collège Moderne Bagohouo</p>
                </div>
              </div>
            </div>

            {/* Texte et Valeurs Républicaines */}
            <div className="lg:col-span-7 space-y-6">
              <div className="inline-flex items-center gap-2 text-xs font-bold text-blue-600 dark:text-blue-400 uppercase tracking-wider">
                <HeartHandshake className="w-4 h-4" />
                <span>Le Mot du Chef d'Établissement</span>
              </div>

              <h3 className="text-2xl sm:text-3xl font-black text-slate-900 dark:text-white leading-tight">
                « L'éducation de qualité est le plus beau cadeau que nous puissions offrir aux enfants de Bagohouo. »
              </h3>

              <div className="text-xs sm:text-sm text-slate-600 dark:text-slate-300 space-y-4 leading-relaxed">
                <p>
                  Chers parents, chers élèves, chers collègues enseignants,
                </p>
                <p>
                  Au <strong>{currentEstablishment.name}</strong>, notre engagement quotidien repose sur
                  trois piliers fondamentaux : la <em>discipline</em>, le <em>travail acharné</em> et la <em>recherche de l'excellence</em>.
                  Implanté au cœur de la belle région du Guémon, notre collège a pour vocation d'offrir
                  à chaque jeune fille et chaque jeune garçon un environnement d’apprentissage moderne,
                  sécurisé et propice à son épanouissement intellectuel et civique.
                </p>
                <p>
                  Grâce à cette plateforme numérique de gestion, nous franchissons un nouveau cap vers
                  la transparence totale et la proximité avec les familles. Vous pouvez désormais suivre
                  les résultats scolaires, les présences et la vie quotidienne de vos enfants en toute sérénité.
                </p>
              </div>

              {/* Three Value Blocks */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 pt-2">
                <div className="p-3.5 rounded-2xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700">
                  <p className="text-xs font-extrabold text-blue-600 dark:text-blue-400">DISCIPLINE</p>
                  <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-1">
                    Respect des règles de la République et ponctualité exemplaire.
                  </p>
                </div>
                <div className="p-3.5 rounded-2xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700">
                  <p className="text-xs font-extrabold text-blue-600 dark:text-blue-400">TRAVAIL</p>
                  <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-1">
                    Rigueur pédagogique, devoirs réguliers et encadrement attentif.
                  </p>
                </div>
                <div className="p-3.5 rounded-2xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700">
                  <p className="text-xs font-extrabold text-blue-600 dark:text-blue-400">SUCCÈS</p>
                  <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-1">
                    Obtention du BEPC et orientation réussie vers le second cycle.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* 7. Section Formations & Niveaux */}
      <section id="formations" className="py-16 sm:py-20 bg-slate-50 dark:bg-slate-950">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center max-w-3xl mx-auto space-y-3 mb-12">
            <span className="text-xs font-bold text-blue-600 dark:text-blue-400 uppercase tracking-wider block">
              Cursus Pédagogique Conforme au Programme National
            </span>
            <h3 className="text-2xl sm:text-3xl font-black text-slate-900 dark:text-white">
              Cycles d'Enseignement Secondaire à Bagohouo
            </h3>
            <p className="text-xs sm:text-sm text-slate-600 dark:text-slate-400">
              Un encadrement complet de la classe de 6ème jusqu'aux classes de 3ème et second cycle,
              avec des coefficients officiels et un suivi personnalisé.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            <div className="p-6 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs">
              <span className="text-2xl font-black text-blue-600 dark:text-blue-400">6ème</span>
              <h4 className="text-sm font-bold text-slate-900 dark:text-white mt-1">
                Accueil & Fondamentaux
              </h4>
              <p className="text-xs text-slate-500 dark:text-slate-400 mt-2 leading-relaxed">
                Transition fluide depuis le primaire (CM2), renforcement du français, des mathématiques
                et initiation aux sciences physiques et d'observation.
              </p>
              <div className="mt-4 pt-3 border-t border-slate-100 dark:border-slate-800 text-[11px] text-slate-400">
                Effectif moyen : 45 élèves / classe
              </div>
            </div>

            <div className="p-6 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs">
              <span className="text-2xl font-black text-blue-600 dark:text-blue-400">5ème</span>
              <h4 className="text-sm font-bold text-slate-900 dark:text-white mt-1">
                Approfondissement
              </h4>
              <p className="text-xs text-slate-500 dark:text-slate-400 mt-2 leading-relaxed">
                Consolidation des compétences scientifiques et littéraires, éveil à l'anglais
                et aux technologies de l'information et de la communication.
              </p>
              <div className="mt-4 pt-3 border-t border-slate-100 dark:border-slate-800 text-[11px] text-slate-400">
                Salles spécialisées disponibles
              </div>
            </div>

            <div className="p-6 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs">
              <span className="text-2xl font-black text-blue-600 dark:text-blue-400">4ème</span>
              <h4 className="text-sm font-bold text-slate-900 dark:text-white mt-1">
                Langues & Esprit Critique
              </h4>
              <p className="text-xs text-slate-500 dark:text-slate-400 mt-2 leading-relaxed">
                Introduction de la seconde langue vivante (Espagnol / Allemand), travaux dirigés
                en physique-chimie et SVT.
              </p>
              <div className="mt-4 pt-3 border-t border-slate-100 dark:border-slate-800 text-[11px] text-slate-400">
                Professeurs principaux dédiés
              </div>
            </div>

            <div className="p-6 rounded-3xl bg-white dark:bg-slate-900 border-2 border-blue-500 shadow-md relative overflow-hidden">
              <div className="absolute top-2 right-2 px-2 py-0.5 rounded-full bg-blue-100 dark:bg-blue-900/50 text-[9px] font-bold text-blue-700 dark:text-blue-300">
                Examen BEPC
              </div>
              <span className="text-2xl font-black text-blue-600 dark:text-blue-400">3ème</span>
              <h4 className="text-sm font-bold text-slate-900 dark:text-white mt-1">
                Préparation Intensive
              </h4>
              <p className="text-xs text-slate-500 dark:text-slate-400 mt-2 leading-relaxed">
                Devoirs communs hebdomadaires, examens blancs régionaux (DRENA Duékoué)
                et préparation complète aux épreuves orales et écrites.
              </p>
              <div className="mt-4 pt-3 border-t border-slate-100 dark:border-slate-800 text-[11px] font-bold text-emerald-600 dark:text-emerald-400">
                Taux de réussite record
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* 8. Section Vie Scolaire & Infrastructures */}
      <section id="viescolaire" className="py-16 sm:py-20 bg-white dark:bg-slate-900 border-b border-slate-200 dark:border-slate-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center max-w-3xl mx-auto space-y-3 mb-12">
            <span className="text-xs font-bold text-blue-600 dark:text-blue-400 uppercase tracking-wider block">
              Cadre de Vie & Épanouissement
            </span>
            <h3 className="text-2xl sm:text-3xl font-black text-slate-900 dark:text-white">
              Infrastructures et Services Dédiés aux Élèves
            </h3>
            <p className="text-xs sm:text-sm text-slate-600 dark:text-slate-400">
              Des équipements modernes conçus pour offrir aux enfants les meilleures conditions de travail.
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            <div className="p-6 rounded-3xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700/60">
              <div className="w-12 h-12 rounded-2xl bg-amber-500/10 text-amber-600 flex items-center justify-center mb-4">
                <Utensils className="w-6 h-6" />
              </div>
              <h4 className="text-sm font-bold text-slate-900 dark:text-white">Cantine Scolaire</h4>
              <p className="text-xs text-slate-500 dark:text-slate-400 mt-1 leading-relaxed">
                Repas chauds, sains et équilibrés servis à midi du lundi au vendredi
                pour préserver la santé et l'énergie des élèves.
              </p>
            </div>

            <div className="p-6 rounded-3xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700/60">
              <div className="w-12 h-12 rounded-2xl bg-blue-500/10 text-blue-600 flex items-center justify-center mb-4">
                <Bus className="w-6 h-6" />
              </div>
              <h4 className="text-sm font-bold text-slate-900 dark:text-white">Transport Scolaire</h4>
              <p className="text-xs text-slate-500 dark:text-slate-400 mt-1 leading-relaxed">
                Ramassage sécurisé desservant les localités du canton de Bagohouo
                et les axes principaux vers Duékoué.
              </p>
            </div>

            <div className="p-6 rounded-3xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700/60">
              <div className="w-12 h-12 rounded-2xl bg-indigo-500/10 text-indigo-600 flex items-center justify-center mb-4">
                <BookOpen className="w-6 h-6" />
              </div>
              <h4 className="text-sm font-bold text-slate-900 dark:text-white">Bibliothèque & CDI</h4>
              <p className="text-xs text-slate-500 dark:text-slate-400 mt-1 leading-relaxed">
                Plus de 1 200 manuels scolaires, romans africains, dictionnaires et annales
                pour la recherche et la lecture.
              </p>
            </div>

            <div className="p-6 rounded-3xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700/60">
              <div className="w-12 h-12 rounded-2xl bg-emerald-500/10 text-emerald-600 flex items-center justify-center mb-4">
                <Laptop className="w-6 h-6" />
              </div>
              <h4 className="text-sm font-bold text-slate-900 dark:text-white">Salle Informatique</h4>
              <p className="text-xs text-slate-500 dark:text-slate-400 mt-1 leading-relaxed">
                Postes informatiques connectés avec initiation aux logiciels de bureautique
                et aux compétences du XXIe siècle.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* 9. Actualités & Annonces Officielles */}
      <section id="actualites" className="py-16 sm:py-20 bg-slate-100/70 dark:bg-slate-950/60">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col sm:flex-row items-start sm:items-end justify-between gap-4 mb-10">
            <div>
              <span className="text-xs font-bold text-blue-600 dark:text-blue-400 uppercase tracking-wider block">
                Vie de l'Établissement
              </span>
              <h3 className="text-2xl sm:text-3xl font-black text-slate-900 dark:text-white">
                Dernières Actualités & Avis Officiels
              </h3>
            </div>
            <span className="text-xs text-slate-500 dark:text-slate-400 font-medium">
              Année 2024-2025 · Bagohouo
            </span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <article className="p-6 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs flex flex-col justify-between">
              <div className="space-y-3">
                <span className="text-[10px] font-bold text-blue-600 dark:text-blue-400 uppercase tracking-wider">
                  Calendrier Pédagogique
                </span>
                <h4 className="text-sm font-bold text-slate-900 dark:text-white">
                  Arrêt des notes du 1er Trimestre et Délibérations
                </h4>
                <p className="text-xs text-slate-500 dark:text-slate-400 leading-relaxed">
                  Les conseils de classe se tiendront du 18 au 22 novembre. Les bulletins seront téléchargeables
                  sur l'Espace Parents dès le 25 novembre.
                </p>
              </div>
              <div className="mt-4 pt-3 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between text-[11px] text-slate-400">
                <span>Direction des Études</span>
                <span>Novembre 2024</span>
              </div>
            </article>

            <article className="p-6 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs flex flex-col justify-between">
              <div className="space-y-3">
                <span className="text-[10px] font-bold text-emerald-600 dark:text-emerald-400 uppercase tracking-wider">
                  Vie Scolaire & COGES
                </span>
                <h4 className="text-sm font-bold text-slate-900 dark:text-white">
                  Assemblée Générale de Rentrée avec les Parents
                </h4>
                <p className="text-xs text-slate-500 dark:text-slate-400 leading-relaxed">
                  Rencontre avec le Comité de Gestion des Établissements Scolaires (COGES) dans la cour d'honneur
                  pour faire le bilan des investissements et de la cantine.
                </p>
              </div>
              <div className="mt-4 pt-3 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between text-[11px] text-slate-400">
                <span>Secrétariat Général</span>
                <span>Octobre 2024</span>
              </div>
            </article>

            <article className="p-6 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs flex flex-col justify-between">
              <div className="space-y-3">
                <span className="text-[10px] font-bold text-amber-600 dark:text-amber-400 uppercase tracking-wider">
                  Excellence Républicaine
                </span>
                <h4 className="text-sm font-bold text-slate-900 dark:text-white">
                  Cérémonie de Salut aux Couleurs Nationales
                </h4>
                <p className="text-xs text-slate-500 dark:text-slate-400 leading-relaxed">
                  Tous les lundis matin à 07h15 précises : montée des couleurs et hymne national l'Abidjanaise,
                  en présence de l'ensemble des élèves et du corps enseignant.
                </p>
              </div>
              <div className="mt-4 pt-3 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between text-[11px] text-slate-400">
                <span>Surveillance Générale</span>
                <span>Hebdomadaire</span>
              </div>
            </article>
          </div>
        </div>
      </section>

      {/* 10. Section Contact & Localisation */}
      <section id="contact" className="py-16 sm:py-20 bg-white dark:bg-slate-900">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-12">
            {/* Contact details */}
            <div className="lg:col-span-5 space-y-6">
              <span className="text-xs font-bold text-blue-600 dark:text-blue-400 uppercase tracking-wider block">
                Localisation & Renseignements
              </span>
              <h3 className="text-2xl sm:text-3xl font-black text-slate-900 dark:text-white">
                Nous Contacter & Nous Rendre Visite
              </h3>
              <p className="text-xs sm:text-sm text-slate-600 dark:text-slate-400 leading-relaxed">
                Le secrétariat du <strong>{currentEstablishment.name}</strong> vous accueille
                pour toute démarche administrative, inscription ou demande d'attestation.
              </p>

              <div className="space-y-4 pt-2">
                <div className="flex items-start gap-3 text-xs">
                  <div className="w-9 h-9 rounded-xl bg-blue-100 dark:bg-blue-900/40 text-blue-600 flex items-center justify-center shrink-0">
                    <MapPin className="w-4 h-4" />
                  </div>
                  <div>
                    <p className="font-bold text-slate-900 dark:text-white">Adresse Physique</p>
                    <p className="text-slate-500 dark:text-slate-400">
                      {currentEstablishment.address}, Bagohouo (Sous-préfecture de Duékoué, Région du Guémon)
                    </p>
                  </div>
                </div>

                <div className="flex items-start gap-3 text-xs">
                  <div className="w-9 h-9 rounded-xl bg-emerald-100 dark:bg-emerald-900/40 text-emerald-600 flex items-center justify-center shrink-0">
                    <Phone className="w-4 h-4" />
                  </div>
                  <div>
                    <p className="font-bold text-slate-900 dark:text-white">Ligne Téléphonique</p>
                    <p className="text-slate-500 dark:text-slate-400">{currentEstablishment.phone}</p>
                  </div>
                </div>

                <div className="flex items-start gap-3 text-xs">
                  <div className="w-9 h-9 rounded-xl bg-indigo-100 dark:bg-indigo-900/40 text-indigo-600 flex items-center justify-center shrink-0">
                    <Mail className="w-4 h-4" />
                  </div>
                  <div>
                    <p className="font-bold text-slate-900 dark:text-white">Courrier Électronique</p>
                    <p className="text-slate-500 dark:text-slate-400">{currentEstablishment.email}</p>
                  </div>
                </div>
              </div>
            </div>

            {/* Quick message form */}
            <div className="lg:col-span-7">
              <div className="p-6 sm:p-8 rounded-3xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700">
                <h4 className="text-base font-bold text-slate-900 dark:text-white mb-2">
                  Laisser un message au secrétariat
                </h4>
                <p className="text-xs text-slate-500 dark:text-slate-400 mb-6">
                  Posez vos questions sur les inscriptions, les bourses scolaires ou le calendrier académique.
                </p>

                {contactSent ? (
                  <div className="p-6 text-center space-y-3 bg-emerald-50 dark:bg-emerald-950/40 rounded-2xl border border-emerald-200 dark:border-emerald-800">
                    <CheckCircle2 className="w-10 h-10 text-emerald-600 mx-auto" />
                    <p className="text-xs font-bold text-emerald-800 dark:text-emerald-200">
                      Votre message a été transmis avec succès au secrétariat du collège.
                    </p>
                    <p className="text-[11px] text-emerald-600 dark:text-emerald-400">
                      Notre équipe vous recontactera dans les plus brefs délais au {contactPhone}.
                    </p>
                  </div>
                ) : (
                  <form onSubmit={handleContactSubmit} className="space-y-4">
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      <div>
                        <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                          Nom & Prénoms *
                        </label>
                        <input
                          type="text"
                          required
                          placeholder="Ex: M. KOUADIO Jean"
                          value={contactName}
                          onChange={(e) => setContactName(e.target.value)}
                          className="w-full px-3.5 py-2 text-xs rounded-xl border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-900 text-slate-900 dark:text-white focus:ring-2 focus:ring-blue-500"
                        />
                      </div>
                      <div>
                        <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                          Numéro de Téléphone *
                        </label>
                        <input
                          type="text"
                          required
                          placeholder="+225 07 00 00 00 00"
                          value={contactPhone}
                          onChange={(e) => setContactPhone(e.target.value)}
                          className="w-full px-3.5 py-2 text-xs rounded-xl border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-900 text-slate-900 dark:text-white focus:ring-2 focus:ring-blue-500"
                        />
                      </div>
                    </div>

                    <div>
                      <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                        Votre Message *
                      </label>
                      <textarea
                        required
                        rows={4}
                        placeholder="Écrivez votre demande ici..."
                        value={contactMessage}
                        onChange={(e) => setContactMessage(e.target.value)}
                        className="w-full px-3.5 py-2 text-xs rounded-xl border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-900 text-slate-900 dark:text-white focus:ring-2 focus:ring-blue-500 resize-none"
                      />
                    </div>

                    <button
                      type="submit"
                      className="w-full py-3 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs shadow-md transition-all flex items-center justify-center gap-2 cursor-pointer"
                    >
                      <span>Transmettre mon message</span>
                    </button>
                  </form>
                )}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* 11. Footer */}
      <footer className="bg-[#0f1f35] text-white py-12 border-t border-white/10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-8 text-xs">
            <div className="space-y-3">
              <div className="flex items-center gap-2.5">
                <School className="w-5 h-5 text-amber-300" />
                <span className="font-extrabold text-sm">{currentEstablishment.name}</span>
              </div>
              <p className="text-slate-400 leading-relaxed text-[11px]">
                Établissement public d'enseignement secondaire général.
                Sous la tutelle de la DRENA Duékoué et du Ministère de l'Éducation Nationale.
              </p>
              <p className="text-amber-300 font-serif italic text-[11px]">{currentEstablishment.motto}</p>
            </div>

            <div>
              <p className="font-bold text-white mb-3 text-xs uppercase tracking-wider">Accès Portails</p>
              <ul className="space-y-2 text-slate-400 text-[11px]">
                <li>
                  <button onClick={() => handleOpenLoginWithRole('directeur')} className="hover:text-white">
                    Espace Direction
                  </button>
                </li>
                <li>
                  <button onClick={() => handleOpenLoginWithRole('enseignant')} className="hover:text-white">
                    Espace Enseignants
                  </button>
                </li>
                <li>
                  <button onClick={() => handleOpenLoginWithRole('parent')} className="hover:text-white">
                    Portail Parents d'Élèves
                  </button>
                </li>
                <li>
                  <button onClick={() => handleOpenLoginWithRole('eleve')} className="hover:text-white">
                    Espace Élèves
                  </button>
                </li>
                <li>
                  <button onClick={() => handleOpenLoginWithRole('comptable')} className="hover:text-white">
                    Espace Comptable
                  </button>
                </li>
              </ul>
            </div>

            <div>
              <p className="font-bold text-white mb-3 text-xs uppercase tracking-wider">Informations Pratiques</p>
              <ul className="space-y-2 text-slate-400 text-[11px]">
                <li>Horaires : 07h30 - 17h30</li>
                <li>Code Établissement : {currentEstablishment.code}</li>
                <li>Région : Guémon · DRENA Duékoué</li>
                <li>Cantine & Transport disponibles</li>
              </ul>
            </div>

            <div>
              <p className="font-bold text-white mb-3 text-xs uppercase tracking-wider">Connexion Rapide</p>
              <p className="text-slate-400 text-[11px] mb-3">
                Accédez à l’environnement de gestion scolaire en un clic.
              </p>
              <button
                onClick={() => setShowLoginModal(true)}
                className="w-full py-2.5 px-3 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs flex items-center justify-center gap-2 cursor-pointer shadow-md"
              >
                <LogIn className="w-3.5 h-3.5" />
                <span>Ouvrir la session</span>
              </button>
            </div>
          </div>

          <div className="pt-8 border-t border-white/10 flex flex-col sm:flex-row items-center justify-between gap-4 text-[11px] text-slate-400">
            <p>© {new Date().getFullYear()} {currentEstablishment.name}. Tous droits réservés.</p>
            <p>Conçu pour l'enseignement en République de Côte d'Ivoire · ScolarCI v2.4</p>
          </div>
        </div>
      </footer>

      {/* Login Modal */}
      {showLoginModal && (
        <LoginModal
          onClose={() => setShowLoginModal(false)}
          defaultRole={defaultLoginRole}
        />
      )}

      {/* Pre-registration Modal */}
      {showPreRegisterModal && (
        <PreRegisterModal onClose={() => setShowPreRegisterModal(false)} />
      )}
    </div>
  );
};
